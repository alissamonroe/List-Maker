package ListProject;

/** TODO  - is this right **/
public interface List {
	
	public String printList();
	public void clearList();
	
}
